import 'package:aiox_app_ui/aiox_app_ui.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'safe_dialog.dart';

enum BrnPageLoadingType { android, ios, custom }

class BrnPageLoading extends StatelessWidget {
  final String? content;
  final BoxConstraints constraints;
  final BrnPageLoadingType? brnPageLoadingType;
  final Widget? iconLoading;

  const BrnPageLoading({
    Key? key,
    this.content,
    this.brnPageLoadingType,
    this.iconLoading,
    this.constraints = const BoxConstraints(
      minWidth: 130,
      maxWidth: 130,
      minHeight: 50,
      maxHeight: 50,
    ),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // double loadingMaxWidth = MediaQuery.of(context).size.width * 2 / 3;
    double iconSize = 19.0;
    double textLeftPadding = 12.0;
    double outPadding = 10.0;
    String loadingText = content ?? "Loading...";

    return Center(
      child: Container(
        padding: EdgeInsets.all(outPadding),
        constraints: BoxConstraints(
          // maxWidth: maxWidth,
          maxWidth: MediaQuery.of(context).size.width * 0.5,
          minWidth: iconSize + textLeftPadding,
        ),
        height: 50,
        // width: loadingMaxWidth,
        decoration: BoxDecoration(
          color: AIOxColors.primary500,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: iconSize,
                width: iconSize,
                child: brnPageLoadingType == BrnPageLoadingType.ios
                    ? const CupertinoActivityIndicator(
                        color: AIOxColors.white500,
                        animating: true,
                      )
                    : brnPageLoadingType == BrnPageLoadingType.android
                        ? const CircularProgressIndicator(
                            strokeWidth: 2.0,
                            valueColor: AlwaysStoppedAnimation(
                              AIOxColors.white500,
                            ),
                          )
                        : iconLoading,
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: textLeftPadding),
                  child: Text(
                    loadingText,
                    maxLines: 1,
                    style: AIOxTextStyles.bodyText12.copyWith(
                      color: AIOxColors.white500,
                      decoration: TextDecoration.none,
                    ),
                    // style: const TextStyle(
                    //     fontSize: 12,
                    //     fontWeight: FontWeight.w600,
                    //     color: Colors.white,
                    //     decoration: TextDecoration.none),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BrnLoadingDialog extends Dialog {
  static const String _loadingDialogTag = '_loadingDialogTag';

  final String? content;

  final BrnPageLoadingType? brnPageLoadingType;

  final Widget? iconLoading;

  const BrnLoadingDialog({
    Key? key,
    this.content,
    this.brnPageLoadingType,
    this.iconLoading,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BrnPageLoading(
      content: content ?? 'Loading...',
      brnPageLoadingType: brnPageLoadingType,
      iconLoading: iconLoading,
    );
  }

  static Future<T?> show<T>(
    BuildContext context, {
    String? content,
    // bool barrierDismissible = true,
    bool barrierDismissible = false,
    bool useRootNavigator = true,
    BrnPageLoadingType? brnPageLoadingType,
    Widget? iconLoading,
  }) {
    return SafeDialog.show<T>(
        context: context,
        tag: _loadingDialogTag,
        barrierDismissible: barrierDismissible,
        useRootNavigator: useRootNavigator,
        builder: (_) {
          return BrnLoadingDialog(
            content: content ?? 'Loading...',
            brnPageLoadingType: brnPageLoadingType ?? BrnPageLoadingType.android,
            iconLoading: iconLoading,
          );
        });
  }

  static void dismiss<T extends Object?>(BuildContext context, [T? result]) {
    SafeDialog.dismiss<T>(context: context, tag: _loadingDialogTag, result: result);
  }
}
