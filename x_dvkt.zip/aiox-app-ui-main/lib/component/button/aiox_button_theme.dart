import 'package:aiox_app_ui/aiox_app_ui.dart';
import 'package:flutter/material.dart';

ElevatedButtonThemeData primaryButtonTheme = ElevatedButtonThemeData(
  style: ButtonStyle(
    alignment: Alignment.center,
    textStyle: MaterialStatePropertyAll(
      AIOxTextStyles.bodyText16.medium(),
    ),
    backgroundColor: MaterialStateProperty.resolveWith(
      (states) {
        //=====DISABLED EVENT
        if (states.contains(MaterialState.disabled)) {
          return AIOxColors.neutral200;
        } else {
          return AIOxColors.primary500;
        }
      },
    ),
    foregroundColor: MaterialStateProperty.resolveWith(
      (states) {
        //=====DISABLED EVENT
        if (states.contains(MaterialState.disabled)) {
          return AIOxColors.neutral600;
        } else {
          return AIOxColors.white500;
        }
      },
    ),
    padding: const MaterialStatePropertyAll<EdgeInsetsGeometry>(EdgeInsets.symmetric(vertical: 17, horizontal: 32)),
    shape: MaterialStatePropertyAll<OutlinedBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
  ),
);

OutlinedButtonThemeData secondaryButtonTheme = OutlinedButtonThemeData(
  style: ButtonStyle(
    textStyle: MaterialStatePropertyAll(
      AIOxTextStyles.bodyText16.medium(),
    ),
    alignment: Alignment.center,
    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(const EdgeInsets.symmetric(vertical: 17, horizontal: 32)),
    shape: MaterialStatePropertyAll<OutlinedBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
    foregroundColor: MaterialStateProperty.resolveWith((states) {
      //=====DISABLED EVENT
      if (states.contains(MaterialState.disabled)) {
        return AIOxColors.white500;
      } else {
        return AIOxColors.white500;
      }
    }),
    side: MaterialStateBorderSide.resolveWith(
      (states) {
        // Disabled EVENT
        if (states.contains(MaterialState.disabled)) {
          return const BorderSide(color: AIOxColors.neutral200);
        } else {
          return const BorderSide(color: AIOxColors.primary500);
        }
      },
    ),
  ),
);

TextButtonThemeData textOnlyButtonTheme = TextButtonThemeData(
  style: ButtonStyle(
    textStyle: MaterialStatePropertyAll(
      AIOxTextStyles.bodyText16.medium(),
    ),
    alignment: Alignment.center,
    padding: MaterialStateProperty.all<EdgeInsetsGeometry>(const EdgeInsets.symmetric(vertical: 17, horizontal: 32)),
    shape: MaterialStatePropertyAll<OutlinedBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
    foregroundColor: MaterialStateProperty.resolveWith(
      (states) {
        if (states.contains(MaterialState.disabled)) {
          return AIOxColors.transparent;
        }
        return AIOxColors.primary500;
      },
    ),
  ),
);

OutlinedButtonThemeData tertiaryButtonTheme = OutlinedButtonThemeData(
    style: ButtonStyle(
  alignment: Alignment.center,
  textStyle: MaterialStatePropertyAll(
    AIOxTextStyles.bodyText16.medium(),
  ),
  backgroundColor: MaterialStateProperty.resolveWith(
    (states) {
      //=====DISABLED EVENT
      if (states.contains(MaterialState.disabled)) {
        return AIOxColors.transparent;
      } else {
        return AIOxColors.neutral300;
      }
    },
  ),
  foregroundColor: MaterialStateProperty.resolveWith(
    (states) {
      //=====DISABLED EVENT
      if (states.contains(MaterialState.disabled)) {
        return AIOxColors.neutral300;
      } else {
        return AIOxColors.primary500;
      }
    },
  ),
  padding: const MaterialStatePropertyAll<EdgeInsetsGeometry>(EdgeInsets.symmetric(vertical: 17, horizontal: 32)),
  shape: MaterialStatePropertyAll<OutlinedBorder>(RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
  side: MaterialStateBorderSide.resolveWith(
    (states) {
      // Disabled EVENT
      if (states.contains(MaterialState.disabled)) {
        return const BorderSide(color: AIOxColors.neutral300);
      } else {
        return const BorderSide(color: AIOxColors.primary500);
      }
    },
  ),
));

ElevatedButtonThemeData roundButtonTheme = ElevatedButtonThemeData(
  style: ButtonStyle(
    alignment: Alignment.center,
    // textStyle: MaterialStatePropertyAll(textTheme.displayLarge),
    backgroundColor: const MaterialStatePropertyAll<Color>(AIOxColors.primary500),
    foregroundColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.disabled)) {
        return AIOxColors.neutral300;
      } else {
        return AIOxColors.neutral300;
      }
    }),
    padding: const MaterialStatePropertyAll<EdgeInsetsGeometry>(EdgeInsets.all(15)),
    shape: const MaterialStatePropertyAll<OutlinedBorder>(CircleBorder()),
  ),
);
