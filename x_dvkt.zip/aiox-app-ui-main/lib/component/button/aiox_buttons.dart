import 'package:aiox_app_ui/aiox_app_ui.dart';
import 'package:aiox_app_ui/component/button/aiox_button_theme.dart';
import 'package:aiox_app_ui/component/button/aiox_buttons_settings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class AIOxButtonWithIconContent extends StatelessWidget {
  final IconPosition? iconPosition;
  final String label;
  final String iconUrl;
  final MainAxisAlignment contentAlignment;
  final bool overrideIconColor;
  final TextStyle? labelStyle;

  const AIOxButtonWithIconContent(
      {required this.label,
      required this.iconUrl,
      required this.contentAlignment,
      this.overrideIconColor = true,
      super.key,
      this.iconPosition,
      this.labelStyle});

  @override
  Widget build(BuildContext context) {
    final List<Widget> buttonContent = [
      SvgPicture.asset(
        iconUrl,
        width: 24,
        height: 24,
        colorFilter: overrideIconColor ? ColorFilter.mode(DefaultTextStyle.of(context).style.color ?? AIOxColors.primary900, BlendMode.srcIn) : null,
        alignment: Alignment.center,
      ),
      Padding(
        padding: iconPosition == IconPosition.left ? const EdgeInsets.only(left: 8) : const EdgeInsets.only(right: 8),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: labelStyle,
        ),
      ),
    ];
    return Row(
      mainAxisAlignment: contentAlignment,
      mainAxisSize: MainAxisSize.max,
      children: iconPosition == IconPosition.left ? buttonContent : buttonContent.reversed.toList(),
    );
  }
}

class AIOxPrimaryButton extends StatelessWidget {
  final String label;
  final String? iconUrl;
  final VoidCallback? onPressed;
  final IconPosition? iconPosition;
  final ButtonStyle? style;
  final MainAxisAlignment contentAlignment;
  final bool overrideIconColor;

  const AIOxPrimaryButton({
    required this.label,
    Key? key,
    this.iconUrl,
    this.onPressed,
    this.iconPosition = IconPosition.left,
    this.style,
    this.contentAlignment = MainAxisAlignment.center,
    this.overrideIconColor = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // FOR TEXT ONLY BUTTON
    if (iconUrl == null) {
      return ElevatedButton(
        key: key,
        onPressed: onPressed,
        style: style,
        child: Row(
          mainAxisAlignment: contentAlignment,
          mainAxisSize: MainAxisSize.max,
          children: [
            Text(label),
          ],
        ),
      );
    }

    return ElevatedButton(
      key: key,
      onPressed: onPressed,
      style: style,
      child: AIOxButtonWithIconContent(
        contentAlignment: contentAlignment,
        iconPosition: iconPosition,
        iconUrl: iconUrl!,
        label: label,
        overrideIconColor: overrideIconColor,
      ),
    );
  }
}

class AIOxSecondaryButton extends StatelessWidget {
  final String label;
  final String? iconUrl;
  final IconPosition? iconPosition;
  final ButtonStyle? style;
  final VoidCallback? onPressed;
  final MainAxisAlignment contentAlignment;
  final bool overrideIconColor;
  final TextStyle? labelStyle;

  const AIOxSecondaryButton(
      {required this.label,
      Key? key,
      this.iconUrl,
      this.onPressed,
      this.iconPosition = IconPosition.left,
      this.style,
      this.contentAlignment = MainAxisAlignment.center,
      this.overrideIconColor = true,
      this.labelStyle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // WITH TEXT ONLY
    if (iconUrl == null) {
      return OutlinedButton(
        onPressed: onPressed,
        style: style,
        child: Row(
          mainAxisAlignment: contentAlignment,
          mainAxisSize: MainAxisSize.max,
          children: [Text(label)],
        ),
      );
    }

    return OutlinedButton(
      onPressed: onPressed,
      style: style,
      child: AIOxButtonWithIconContent(
        contentAlignment: contentAlignment,
        iconPosition: iconPosition,
        iconUrl: iconUrl!,
        label: label,
        labelStyle: labelStyle,
        overrideIconColor: overrideIconColor,
      ),
    );
  }
}

class AIOxTextOnlyButton extends StatelessWidget {
  final String label;
  final String? iconUrl;
  final VoidCallback? onPressed;
  final IconPosition? iconPosition;
  final ButtonStyle? style;
  final MainAxisAlignment contentAlignment;

  const AIOxTextOnlyButton({
    required this.label,
    Key? key,
    this.onPressed,
    this.iconUrl,
    this.iconPosition = IconPosition.left,
    this.contentAlignment = MainAxisAlignment.center,
    this.style,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (iconUrl == null) {
      return TextButton(
        key: key,
        onPressed: onPressed,
        style: style,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Text(label),
          ],
        ),
      );
    }

    return TextButton(
        key: key,
        onPressed: onPressed,
        style: style,
        child: AIOxButtonWithIconContent(
          contentAlignment: contentAlignment,
          iconPosition: iconPosition,
          iconUrl: iconUrl!,
          label: label,
        ));
  }
}

class AIOxTertiaryButton extends StatelessWidget {
  final String label;
  final String? iconUrl;
  final VoidCallback? onPressed;
  final IconPosition? iconPosition;
  final ButtonStyle? style;
  final MainAxisAlignment contentAlignment;
  final bool overrideIconColor;

  const AIOxTertiaryButton({
    required this.label,
    Key? key,
    this.onPressed,
    this.iconUrl,
    this.iconPosition = IconPosition.left,
    this.contentAlignment = MainAxisAlignment.center,
    this.style,
    this.overrideIconColor = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (iconUrl == null) {
      return OutlinedButton(
        key: key,
        onPressed: onPressed,
        style: style ?? tertiaryButtonTheme.style,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            Text(label),
          ],
        ),
      );
    }

    return OutlinedButton(
        key: key,
        onPressed: onPressed,
        style: style ?? tertiaryButtonTheme.style,
        child: AIOxButtonWithIconContent(
          contentAlignment: contentAlignment,
          iconPosition: iconPosition,
          iconUrl: iconUrl!,
          label: label,
          overrideIconColor: overrideIconColor,
        ));
  }
}

class AIOxRoundButton extends StatelessWidget {
  final String iconUrl;
  final VoidCallback? onPressed;
  final ButtonStyle? style;
  final Color? textColor;

  const AIOxRoundButton({
    required this.iconUrl,
    required this.onPressed,
    this.style,
    Key? key,
    this.textColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: style ?? roundButtonTheme.style,
      child: SvgPicture.asset(
        iconUrl,
        width: 24,
        height: 24,
        colorFilter: ColorFilter.mode(DefaultTextStyle.of(context).style.color ?? AIOxColors.neutral300, BlendMode.srcIn),
      ),
    );
  }
}

class AIOxDropDownButton extends StatelessWidget {
  final String? value;
  final VoidCallback onPressed;
  final String? icon;
  final TextStyle? labelStyle;

  const AIOxDropDownButton({
    required this.onPressed,
    super.key,
    bool? isRequired,
    this.icon,
    this.value,
    this.labelStyle,
  });

  @override
  Widget build(BuildContext context) {
    return AIOxSecondaryButton(
      label: value ?? '',
      labelStyle: labelStyle,
      iconUrl: icon,
      iconPosition: IconPosition.right,
      contentAlignment: MainAxisAlignment.spaceBetween,
      style: secondaryButtonTheme.style?.copyWith(
        textStyle: MaterialStatePropertyAll<TextStyle?>(
          Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.5),
        ),
        padding: const MaterialStatePropertyAll<EdgeInsets>(
          EdgeInsets.fromLTRB(AIOxDimens.dimens2x, AIOxDimens.dimens, AIOxDimens.dimens, AIOxDimens.dimens),
        ),
      ),
      onPressed: onPressed,
    );
  }
}

// class HsBackButton extends StatelessWidget {
//   const HsBackButton({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return IconButton(
//       onPressed: () => Navigator.pop(context),
//       icon: SvgPicture.asset(Assets.icons.arrowCalendarLeft),
//     );
//   }
// }
