class AIOxDimens {
  /// The default unit of spacing
  static const double dimens = 8;
  static const double dimens2x = 16;
  static const double dimens3x = 24;
  static const double dimens4x = 32;
  static const double dimens5x = 40;
}