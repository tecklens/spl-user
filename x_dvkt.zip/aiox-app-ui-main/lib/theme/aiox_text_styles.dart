import 'package:aiox_app_ui/aiox_app_ui.dart';
import 'package:aiox_app_ui/theme/aiox_font_weight.dart';
import 'package:flutter/material.dart';

abstract class AIOxTextStyles {
  static const _baseTextStyle = TextStyle(
    fontWeight: AIOxFontWeight.regular,
    fontStyle: FontStyle.normal,
    color: AIOxColors.black500,
  );

  static const TextStyle nav = TextStyle(
    fontSize: 10,
    height: 12 / 10,
    letterSpacing: 0,
    color: Colors.white,
  );

  /// ----- font QuickSans ------///
  static const TextStyle aIOHeadingMobileHeadingXL = TextStyle(
    fontSize: 18,
    fontWeight: AIOxFontWeight.bold,
    height: 1.33,
  );
  static const TextStyle aIOHeadingMobileHeading4XL = TextStyle(
    fontSize: 32,
    height: 1.25,
  );
  static const TextStyle aIOHeadingMobileHeading3XL = TextStyle(
    fontSize: 24,
    fontWeight: AIOxFontWeight.bold,
    height: 1.33,
  );
  static const TextStyle aIOHeadingMobileHeading2XL = TextStyle(
    fontSize: 20,
    fontWeight: AIOxFontWeight.bold,
    height: 1.4,
  );
  static const TextStyle aIOHeadingMobileHeadingLG = TextStyle(
    fontSize: 16,
    fontWeight: AIOxFontWeight.bold,
    height: 1.5,
  );

  /// ----- font FS BeauSans Pro ------///
  static const TextStyle vCCHeadingMobileHeading4XL = TextStyle(
    fontSize: 32,
    fontWeight: AIOxFontWeight.bold,
    height: 1.44,
  );
  static const TextStyle vCCHeadingMobileHeading3XL = TextStyle(
    fontSize: 24,
    fontWeight: AIOxFontWeight.bold,
    height: 1.42,
  );
  static const TextStyle vCCHeadingMobileHeading2XL = TextStyle(
    fontSize: 20,
    fontWeight: AIOxFontWeight.bold,
    height: 1.4,
  );
  static const TextStyle vCCHeadingMobileHeadingXL = TextStyle(
    fontSize: 18,
    fontWeight: AIOxFontWeight.bold,
    height: 1.44,
  );
  static const TextStyle vCCHeadingMobileHeadingLG = TextStyle(
    fontSize: 16,
    fontWeight: AIOxFontWeight.bold,
    height: 1.5,
  );

  /// ----- font SF Pro Text ------///
  static const TextStyle bodyText10 = TextStyle(
    fontSize: 10,
    fontWeight: AIOxFontWeight.regular,
    height: 1.2,
  );
  static const TextStyle bodyText11 = TextStyle(
    fontSize: 11,
    fontWeight: AIOxFontWeight.regular,
    height: 1.27,
  );
  static const TextStyle bodyText12 = TextStyle(
    fontSize: 12,
    fontWeight: AIOxFontWeight.regular,
    height: 1.33,
  );
  static const TextStyle bodyText13 = TextStyle(
    fontSize: 13,
    fontWeight: AIOxFontWeight.regular,
    height: 1.38,
  );
  static const TextStyle bodyText14 = TextStyle(
    fontSize: 14,
    fontWeight: AIOxFontWeight.regular,
    height: 1.43,
  );
  static const TextStyle bodyText16 = TextStyle(
    fontSize: 16,
    fontWeight: AIOxFontWeight.regular,
    height: 1.5,
  );
  static const TextStyle bodyText18 = TextStyle(
    fontSize: 18,
    fontWeight: AIOxFontWeight.regular,
    height: 1.56,
  );
}

extension AppTextStyle on TextStyle {
  TextStyle bold() {
    return copyWith(
      fontWeight: AIOxFontWeight.bold,
    );
  }

  TextStyle semiBold() {
    return copyWith(
      fontWeight: AIOxFontWeight.semiBold,
    );
  }

  TextStyle medium() {
    return copyWith(
      fontWeight: AIOxFontWeight.medium,
    );
  }

  TextStyle regular() {
    return copyWith(
      fontWeight: AIOxFontWeight.regular,
    );
  }
}
